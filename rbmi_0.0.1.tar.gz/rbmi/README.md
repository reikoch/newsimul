<!-- badges: start -->
[![R-CMD-check](https://github.com/insightsengineering/rbmi/workflows/R-CMD-check/badge.svg)](https://github.com/insightsengineering/rbmi/actions)
[![Codecov test coverage](https://codecov.io/gh/insightsengineering/rbmi/branch/master/graph/badge.svg)](https://codecov.io/gh/insightsengineering/rbmi?branch=master)
<!-- badges: end -->


# Reference Based Multiple Imputation (RMBI)

TODO



 