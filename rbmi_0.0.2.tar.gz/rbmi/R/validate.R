
#' TODO
#'
#' @param x TODO
#' @param ... TODO
#'
#' @export
validate <- function(x, ...) {
    UseMethod("validate")
}
