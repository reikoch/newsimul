library(testthat)
library(rbmi)

test_check("rbmi")
